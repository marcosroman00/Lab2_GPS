package cr.ac.una.gps.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class PuntoPoligono(
    @PrimaryKey(autoGenerate = true) val id: Long?,
    val latitud: Double,
    val longitud: Double

) {
    override fun toString(): String {
        return "Latitud: $latitud \nLongitud: $longitud \n"
    }
}
