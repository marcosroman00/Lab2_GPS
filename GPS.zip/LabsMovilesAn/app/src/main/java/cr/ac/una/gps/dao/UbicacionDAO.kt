package cr.ac.una.gps.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import cr.ac.una.gps.entity.Ubicacion
import java.util.Date


@Dao
interface UbicacionDao {
    @Insert
    fun insert(entity: Ubicacion)

    @Update
    fun update(entity: Ubicacion)


    @Query("SELECT * FROM ubicacion")
    fun getAll(): List<Ubicacion?>?

    @Query("SELECT * FROM ubicacion WHERE fecha = :date")
    fun getByDate(date: String): List<Ubicacion>


}