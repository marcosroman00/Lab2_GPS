package cr.ac.una.gps

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import cr.ac.una.gps.db.AppDatabase
import cr.ac.una.gps.entity.PuntoPoligono
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RestringedArea : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_restringed_area, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Inicializa la base de datos y el DAO
        val db = AppDatabase.getInstance(requireContext()).puntoPoligonoDao()

        // Inicializa el TextView
        val textView: TextView = view.findViewById(R.id.textView)

        // Carga los puntos existentes
        CoroutineScope(Dispatchers.IO).launch {
            val puntos = db.getAll() ?: emptyList()
            withContext(Dispatchers.Main) {
                textView.text = puntos.joinToString(separator = "\n")
            }
        }

        // Agrega un nuevo punto
        val addButton: Button = view.findViewById(R.id.addButton)
        val latitudeEditText: EditText = view.findViewById(R.id.latitudeEditText)
        val longitudeEditText: EditText = view.findViewById(R.id.longitudeEditText)

        addButton.setOnClickListener {
            val latitud = latitudeEditText.text.toString().toDoubleOrNull()
            val longitud = longitudeEditText.text.toString().toDoubleOrNull()

            if (latitud != null && longitud != null) {
                val newPunto = PuntoPoligono(id = null, latitud = latitud, longitud = longitud)
                CoroutineScope(Dispatchers.IO).launch {
                    db.insert(newPunto)
                    val puntos = db.getAll() ?: emptyList()
                    withContext(Dispatchers.Main) {
                        textView.text = puntos.joinToString(separator = "\n")
                    }
                }
            } else {
                textView.text = "Error: Latitud y longitud deben ser números"
            }
        }
    }


}
