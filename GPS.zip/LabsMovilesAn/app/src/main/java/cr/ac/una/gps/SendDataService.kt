package cr.ac.una.gps

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.Binder
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class SendDataService : Service() {
    private val binder = MyBinder()
    private val _markerTitle = MutableLiveData<String>("Ubicación actual ")
    val markerTitle: LiveData<String> = _markerTitle

    override fun onBind(intent: Intent): IBinder {
        return binder
    }

    fun updateMarkerTitle(newTitle: String) {
        _markerTitle.value = newTitle
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        _markerTitle.value = intent?.getStringExtra("markerTitle") ?: "Ubicación actual"
        return super.onStartCommand(intent, flags, startId)
    }

    inner class MyBinder : Binder() {
        fun getService(): SendDataService = this@SendDataService
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}
