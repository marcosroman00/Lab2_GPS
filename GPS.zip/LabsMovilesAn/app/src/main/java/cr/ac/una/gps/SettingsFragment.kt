package cr.ac.una.gps

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.core.content.edit
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment() {

    private lateinit var editText: EditText
    private lateinit var button: Button
    private lateinit var myService: SendDataService

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as SendDataService.MyBinder
            myService = binder.getService()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            myService.onDestroy()
        }
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_setting, container, false)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        editText = view.findViewById(R.id.edit_text_settings)
        button = view.findViewById(R.id.buttonEnviar)

        val intent = Intent(context, SendDataService::class.java)
        context?.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)

        button.setOnClickListener {
            val text = editText.text.toString().trim()
            val markerTitle = if (text.isNotEmpty()) text else "Ubicación actual"


            activity?.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)?.edit {
                putString("markerTitle", markerTitle)
            }

            myService.updateMarkerTitle(markerTitle)
            Log.d("SettingsFragment", "markerTitle: $markerTitle")
        }

    }

}
