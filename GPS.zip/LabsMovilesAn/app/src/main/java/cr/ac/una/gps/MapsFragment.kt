import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.*
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.text.InputType
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.Marker
import cr.ac.una.gps.dao.UbicacionDao
import cr.ac.una.gps.db.AppDatabase
import cr.ac.una.gps.entity.Ubicacion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.Polygon
import com.google.android.gms.maps.model.PolygonOptions
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.maps.android.PolyUtil
import cr.ac.una.gps.LocationService
import cr.ac.una.gps.R
import cr.ac.una.gps.SendDataService
import cr.ac.una.gps.dao.PuntoPoligonoDao
import cr.ac.una.gps.entity.PuntoPoligono
import java.text.ParseException
import java.text.SimpleDateFormat


class MapsFragment : Fragment() {

    private val REQUEST_LOCATION_PERMISSION = 1
    private lateinit var googleMap: GoogleMap
    private val pastLocations = mutableListOf<LatLng>()
    private var lastReceivedLocation: LatLng? = null
    private var lastMarker: Marker? = null

    private lateinit var ubicacionDao: UbicacionDao
    private lateinit var puntoPoligonoDao: PuntoPoligonoDao

    private lateinit var polygon: Polygon
    private val markerPoints = mutableListOf<LatLng>()
    private val newPoligonData = mutableListOf<LatLng>()
    private var isFilteredByDate = false
    private var filteredDate = ""



    private lateinit var locationReceiver: BroadcastReceiver
    private lateinit var fusedLocationClient: FusedLocationProviderClient


    private lateinit var myService: SendDataService


    private var markerTitle: String = "Ubicación actual"
    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as SendDataService.MyBinder // Obtén el binder del servicio
            myService = binder.getService() // Obtén la instancia del servicio

            myService.markerTitle.observe(viewLifecycleOwner, Observer { newTitle ->
                markerTitle = newTitle
                lastMarker?.title = markerTitle
                lastMarker?.showInfoWindow()

                activity?.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)?.edit {
                    putString(MARKER_TITLE_KEY, markerTitle)
                }
            })
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            myService.onDestroy()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_maps, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val intent = Intent(context, SendDataService::class.java)
        context?.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        ubicacionDao = AppDatabase.getInstance(requireContext()).ubicacionDao()
        puntoPoligonoDao = AppDatabase.getInstance(requireContext()).puntoPoligonoDao()


        val sendDataIntent = Intent(requireContext(), SendDataService::class.java)
        requireContext().startService(sendDataIntent)

        val locationServiceIntent = Intent(requireContext(), LocationService::class.java)
        requireContext().startService(locationServiceIntent)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this.requireContext())

        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(callback)

        val filterButton: Button = view.findViewById(R.id.filter_button)
        filterButton.setOnClickListener {
            showDateInputDialog()
        }


        val createPolygonButton: Button = view.findViewById(R.id.create_polygon_button)
        createPolygonButton.setOnClickListener {
            if (markerPoints.isNotEmpty() && markerPoints.size >= 3) {
                polygon.remove()
                googleMap.clear()
                polygon = createPolygonFromMarkerPoints()
                markerPoints.clear()
            } else {
                Toast.makeText(requireContext(), "Agregue al menos 3 marcadores para crear un polígono.", Toast.LENGTH_LONG).show()
                googleMap.clear()
                lifecycleScope.launch {
                addMarketOnMapToDatabase()
                }
            }


        }
        initLocationReceiver()
        context?.registerReceiver(locationReceiver, IntentFilter("ubicacionActualizada"))

    }

    private fun isLocationInsidePolygon(location: LatLng): Boolean {
        return ::polygon.isInitialized && PolyUtil.containsLocation(location, polygon.points, true)
    }


    private fun saveLocationToDatabase(ubicacion: Ubicacion) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                ubicacionDao.insert(ubicacion)
            }
        }
    }

    private fun deleteAllPolygonPointsFromDatabase() {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                puntoPoligonoDao.deleteAll()
            }
        }
    }


    private fun savePolygonPointToDatabase(puntoPoligono: PuntoPoligono) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                puntoPoligonoDao.insert(puntoPoligono)
            }
        }
    }

    private suspend fun addMarketOnMapToDatabase(){
        val ubicaciones = withContext(Dispatchers.IO) {
            ubicacionDao.getAll()
        }
        ubicaciones?.forEach { ubicacion ->
            ubicacion?.let { nonNullUbicacion ->
                val location = LatLng(nonNullUbicacion.latitud, nonNullUbicacion.longitud)

                googleMap.addMarker(
                    MarkerOptions().position(location).title(nonNullUbicacion.fecha)
                        .icon(BitmapDescriptorFactory.defaultMarker(getMarkerColor(nonNullUbicacion.area_restringida)))
                )
            }
        }
    }

    private fun createPolygonFromMarkerPoints(): Polygon {
        val polygonOptions = PolygonOptions()
        markerPoints.forEach { point ->
            polygonOptions.add(point)
        }

        polygonOptions.strokeWidth(5f)
        polygonOptions.strokeColor(ContextCompat.getColor(requireContext(), R.color.colorPrimaryDark))


        val newPolygon = googleMap.addPolygon(polygonOptions)


        deleteAllPolygonPointsFromDatabase()

        markerPoints.forEach { point ->
            val puntoPoligono = PuntoPoligono(null, point.latitude, point.longitude)
            savePolygonPointToDatabase(puntoPoligono)
        }

        updateMarkersInPolygon()

        return newPolygon
    }


    private fun getMarkerColor(area_restringida: Boolean): Float {
        return if (area_restringida) {
            BitmapDescriptorFactory.HUE_GREEN
        } else {
            BitmapDescriptorFactory.HUE_RED
        }
    }

    private fun updateMarkersInPolygon() {
        lifecycleScope.launch {
            val ubicaciones = withContext(Dispatchers.IO) {
                ubicacionDao.getAll()
            }
            ubicaciones?.forEach { ubicacion ->
                ubicacion?.let { nonNullUbicacion ->
                    val location = LatLng(nonNullUbicacion.latitud, nonNullUbicacion.longitud)
                    val insidePolygon = isLocationInsidePolygon(location)
                    if (nonNullUbicacion.area_restringida != insidePolygon) {
                        val updatedUbicacion = nonNullUbicacion.copy(area_restringida = insidePolygon)
                        withContext(Dispatchers.IO) {
                            ubicacionDao.update(updatedUbicacion)
                        }
                    }
                }
            }


            addMarketOnMapToDatabase()
        }
    }

    private fun addPolygonToMap() {
        val polygonOptions = PolygonOptions()
        polygonOptions.addAll(polygon.points)
        polygonOptions.strokeWidth(5f)
        polygonOptions.strokeColor(ContextCompat.getColor(requireContext(), R.color.colorPrimaryDark))

        googleMap.addPolygon(polygonOptions)
    }




    private fun showDateInputDialog() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Ingrese la fecha")

        val input = EditText(requireContext())
        input.inputType = InputType.TYPE_CLASS_DATETIME
        input.hint = "dd/MM/yyyy"
        builder.setView(input)

        builder.setPositiveButton("Filtrar") { _, _ ->
            val dateString = input.text.toString()
            val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            try {
                dateFormat.parse(dateString)
                isFilteredByDate = true
                filteredDate = dateString
                lifecycleScope.launch {
                    filterLocationsByDate(dateString)
                }
            } catch (e: ParseException) {
                Toast.makeText(requireContext(), "Ingrese una fecha válida", Toast.LENGTH_LONG).show()
            }
        }
        builder.setNegativeButton("Cancelar") { dialog, _ -> dialog.cancel() }

        builder.show()
    }


    private suspend fun filterLocationsByDate(dateString: String) {
        googleMap.clear()
        addPolygonToMap()

        val filteredLocations = withContext(Dispatchers.IO) {
            ubicacionDao.getByDate(dateString)
        }

        if (filteredLocations.isNotEmpty()) {

            filteredLocations.forEach { ubicacion ->
                googleMap.addMarker(
                    MarkerOptions()
                        .position(LatLng(ubicacion.latitud, ubicacion.longitud))
                        .title(ubicacion.fecha)
                        .icon(BitmapDescriptorFactory.defaultMarker(getMarkerColor(ubicacion.area_restringida)))
                )
            }
        } else {
            Toast.makeText(requireContext(), "No se encontraron ubicaciones en la fecha seleccionada.", Toast.LENGTH_LONG).show()
        }


    }


    @SuppressLint("MissingPermission")
    private val callback = OnMapReadyCallback { googleMap ->
        this.googleMap = googleMap
        configureMapUiSettings(googleMap)


        googleMap.setOnMapClickListener { latLng ->
            googleMap.addMarker(
                MarkerOptions().position(latLng).title(markerTitle)
            )
            markerPoints.add(latLng)
            newPoligonData.add(latLng)
        }

        Log.d("LocationFilter", "Se encontraron ${markerPoints.size} ubicaciones. Y estoy en el callback")


        lifecycleScope.launch {
            polygon = createPolygon()
        }


        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                REQUEST_LOCATION_PERMISSION
            )
        } else {
            googleMap.isMyLocationEnabled = true

            lifecycleScope.launch {
                val ubicaciones = withContext(Dispatchers.IO) {
                    ubicacionDao.getAll()
                }
                ubicaciones?.forEach { ubicacion ->
                    ubicacion?.let { nonNullUbicacion ->
                        pastLocations.add(LatLng(nonNullUbicacion.latitud, nonNullUbicacion.longitud))
                    }
                }
                updateMapMarkers()
                addMarketOnMapToDatabase()
            }
        }
    }


    private fun configureMapUiSettings(googleMap: GoogleMap) {
        googleMap.uiSettings.apply {
            isZoomControlsEnabled = true
            isMyLocationButtonEnabled = true
            isCompassEnabled = true
            isMapToolbarEnabled = true
            isIndoorLevelPickerEnabled = true
            isRotateGesturesEnabled = true
            isScrollGesturesEnabled = true
            isTiltGesturesEnabled = true
            isZoomGesturesEnabled = true
            isScrollGesturesEnabledDuringRotateOrZoom = true
        }
    }

    private fun initLocationReceiver() {
        Log.d("LocationFilter", "Estoy en initLocationReceiver.")
        locationReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val latitud = intent?.getDoubleExtra("latitud", 0.0) ?: 0.0
                val longitud = intent?.getDoubleExtra("longitud", 0.0) ?: 0.0
                val location = LatLng(latitud, longitud)


                if (isLocationInsidePolygon(location)) {
                    callEmergencyPhoneNumber()

                    if (location != lastReceivedLocation) {
                        lastReceivedLocation = location

                        pastLocations.add(location)

                        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                        val fecha = dateFormat.format(Date())
                        val ubicacion = Ubicacion(
                            id = null,
                            latitud = latitud,
                            longitud = longitud,
                            fecha = fecha,
                            area_restringida = isLocationInsidePolygon(location)
                        )
                        saveLocationToDatabase(ubicacion)
                    }
                } else {
                    if (location != lastReceivedLocation) {
                        lastReceivedLocation = location

                        pastLocations.add(location)

                        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                        val fecha = dateFormat.format(Date())
                        val ubicacion = Ubicacion(
                            id = null,
                            latitud = latitud,
                            longitud = longitud,
                            fecha = fecha,
                            area_restringida = isLocationInsidePolygon(location)
                        )
                        saveLocationToDatabase(ubicacion)
                    }
                }


                if (lastReceivedLocation != null && location != lastReceivedLocation) {
                    lastMarker?.remove()
                }

                lastMarker = googleMap.addMarker(
                    MarkerOptions().position(location).title(markerTitle)
                        .icon(BitmapDescriptorFactory.defaultMarker(getMarkerColor(isLocationInsidePolygon(location))))
                )
                //googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 12f))

                lastReceivedLocation = location
            }
        }
    }

    private fun callEmergencyPhoneNumber() {
        val sharedPreferences = requireContext().getSharedPreferences("emergencyPhoneNumberPrefs", Context.MODE_PRIVATE)
        val phoneNumber = sharedPreferences.getString("emergencyPhoneNumber", null)

        if (phoneNumber != null) {
            val intent = Intent(Intent.ACTION_CALL)
            intent.data = Uri.parse("tel:$phoneNumber")

            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                startActivity(intent)
            } else {
                ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.CALL_PHONE), REQUEST_CALL_PERMISSION)
            }
        } else {
            Toast.makeText(requireContext(), "No hay número de emergencia registrado.", Toast.LENGTH_LONG).show()
        }
    }


    private fun updateMapMarkers() {
        lastMarker?.remove()

        if (pastLocations.isNotEmpty()) {
            val currentLocation = pastLocations.last()
            lastMarker = googleMap.addMarker(
                MarkerOptions().position(currentLocation).title(markerTitle)
            )
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 8f))
        }
    }

    private suspend fun getPolygonPointsFromDatabase(): List<LatLng> {
        val puntosPoligono = withContext(Dispatchers.IO) {
            puntoPoligonoDao.getAll()
        }
        return puntosPoligono.orEmpty()
            .filterNotNull()
            .map { puntoPoligono ->
                LatLng(puntoPoligono.latitud, puntoPoligono.longitud)
            }
    }


    private fun createDefaultPolygon(): Polygon {
        val polygonOptions = PolygonOptions()
        polygonOptions.add(LatLng(10.4579261,-84.518263))
        polygonOptions.add(LatLng( 10.0254762,-84.1282484))
        polygonOptions.add(LatLng( 10.0957892,-83.6063978))
        polygonOptions.add(LatLng( 10.3768869,-83.4745619))
        polygonOptions.add(LatLng( 10.5281431,-83.8206312 ))
        polygonOptions.add(LatLng( 10.4579261,-84.518263))
        polygonOptions.strokeWidth(5f)
        polygonOptions.strokeColor(ContextCompat.getColor(requireContext(), R.color.colorPrimaryDark))

        return googleMap.addPolygon(polygonOptions)
    }


    private suspend fun createPolygon(): Polygon {
        val polygonPoints = getPolygonPointsFromDatabase()
        if (polygonPoints.isEmpty()) {
            return createDefaultPolygon()
        }

        val polygonOptions = PolygonOptions()
        polygonOptions.addAll(polygonPoints)
        polygonOptions.strokeWidth(5f)
        polygonOptions.strokeColor(ContextCompat.getColor(requireContext(), R.color.colorPrimaryDark))

        return googleMap.addPolygon(polygonOptions)
    }


    private fun addMarkersToPolygonVertices(vertices: List<LatLng>) {
        vertices.forEach { vertex ->
            googleMap.addMarker(
                MarkerOptions()
                    .position(vertex)
                    .title("Vértice del polígono")
            )
        }
    }





    override fun onResume() {
        super.onResume()
        lastMarker?.title = markerTitle
        lastMarker?.showInfoWindow()
        context?.registerReceiver(locationReceiver, IntentFilter("ubicacionActualizada"))
    }

    override fun onPause() {
        super.onPause()
        context?.unregisterReceiver(locationReceiver)
    }

    override fun onDestroyView() {
        super.onDestroyView()

        // Detener los servicios SendDataService y LocationService
        val sendDataIntent = Intent(requireContext(), SendDataService::class.java)
        requireContext().stopService(sendDataIntent)

        val locationServiceIntent = Intent(requireContext(), LocationService::class.java)
        requireContext().stopService(locationServiceIntent)

        context?.unbindService(serviceConnection)
    }

    companion object {
        private const val MARKER_TITLE_KEY = "marker_title"
        private const val REQUEST_LOCATION_PERMISSION = 1
        private const val REQUEST_CALL_PERMISSION = 2
    }
}