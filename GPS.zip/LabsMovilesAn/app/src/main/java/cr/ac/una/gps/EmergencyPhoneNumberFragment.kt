import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import cr.ac.una.gps.R

class EmergencyPhoneNumberFragment : Fragment() {

    private lateinit var phoneNumberEditText: EditText
    private lateinit var savePhoneNumberButton: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_emergency_phone_number, container, false)

        phoneNumberEditText = view.findViewById(R.id.phoneNumberEditText)
        savePhoneNumberButton = view.findViewById(R.id.savePhoneNumberButton)

        savePhoneNumberButton.setOnClickListener {
            val phoneNumber = phoneNumberEditText.text.toString()
            if (phoneNumber.isNotEmpty()) {
                saveEmergencyPhoneNumber(requireContext(), phoneNumber)
                Toast.makeText(requireContext(), "Número de emergencia guardado.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Por favor, ingrese un número de teléfono.", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }

    private fun saveEmergencyPhoneNumber(context: Context, phoneNumber: String) {
        val sharedPreferences = context.getSharedPreferences("emergencyPhoneNumberPrefs", Context.MODE_PRIVATE)
        sharedPreferences.edit().putString("emergencyPhoneNumber", phoneNumber).apply()
    }
}
