package cr.ac.una.gps.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import cr.ac.una.gps.entity.PuntoPoligono

@Dao
interface PuntoPoligonoDao {
    @Insert
    fun insert(entity: PuntoPoligono)

    @Query("SELECT * FROM PuntoPoligono")
    fun getAll(): List<PuntoPoligono?>?

    @Delete
    fun delete(entity: PuntoPoligono)

    @Query("DELETE FROM PuntoPoligono")
    fun deleteAll()

    @Update
    fun update(entity: PuntoPoligono)
}
